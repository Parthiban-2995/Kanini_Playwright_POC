import { test as base } from './baseFixture';

type LoginData = {
    username: string;
    password: string;
    dashboardTitle?: string;
    errorMessage?: string;
};

type LoginFixtures = {
    loginData: {
        validLogin: LoginData;
        invalidLogin: LoginData;
    };
};

export const test = base.extend<LoginFixtures>({
    loginData: async ({}, use) => {
        await use({
            validLogin: {
                username: "jason@gmail.com",
                password: "password",
                dashboardTitle: "Dashboard · Smart Hospital"
            },
            invalidLogin: {
                username: "jason@gmail.com",
                password: "passwod",
                errorMessage: "Invalid Username or Password"
            }
        });
    }
});
