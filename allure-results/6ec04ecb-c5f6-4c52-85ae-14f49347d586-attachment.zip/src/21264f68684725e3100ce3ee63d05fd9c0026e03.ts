import { test } from '../fixtures/appointmentFixture';

test.describe.configure({mode:'serial'})
test('Add Appointment', async ({ appointmentPage, appointmentData }) => {
  await appointmentPage.selectAppointmentMenu();
  await appointmentPage.clickAddAppointmentButton();
  await appointmentPage.selectPatient(appointmentData.patientName);
  await appointmentPage.addAppointmentDetails(appointmentData.appointmentDetails);
});


test('Delete appointment', async ({ appointmentPage, appointmentData }) => {
  await appointmentPage.selectAppointmentMenu();
  await appointmentPage.deleteAppointment(appointmentData.patientName, appointmentData.patientId);
});
