import { test } from '../fixtures/appointmentFixture';

test('Add Appointment', async ({ appointmentPage, appointmentData }) => {
  await appointmentPage.selectAppointmentMenu();
  await appointmentPage.clickAddAppointmentButton();
  await appointmentPage.selectPatient(appointmentData.patientName);
  await appointmentPage.addAppointmentDetails(appointmentData.appointmentDetails);
});
