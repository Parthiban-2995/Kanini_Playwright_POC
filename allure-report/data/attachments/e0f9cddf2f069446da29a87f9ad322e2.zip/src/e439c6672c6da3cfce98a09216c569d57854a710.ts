import { test as base } from './authenticatedFixture';
import { AppointmentPage, type appointmentDetails } from '../pageobjects/AppointmentPage';

type AppointmentData = {
  patientName: string;
  appointmentDetails: appointmentDetails;
};

type AppointmentFixtures = {
  appointmentPage: AppointmentPage;
  appointmentData: AppointmentData;
};

export const test = base.extend<AppointmentFixtures>({
  appointmentPage: async ({ pages }, use) => {
    await use(pages.appointmentPage);
  },
  appointmentData: async ({}, use) => {
    await use({
      patientName: 'SARATH',
      appointmentDetails: {
        doctor: 'Sansa Gomez (9008)',
        shift: 'Evening',
        appointmentDate: '23/09/2026 12:43 PM',
        slot: '96',
        appointmentPriority: 'Normal',
        status: 'approved',
        discountPercentage: '10',
        liveConsultant: 'no',
        paymentMode: 'Cash',
        message: 'Appointment message',
        alternateAddress: 'PATIENT_ADDRESS'
      }
    });
  },
});

export { expect } from '@playwright/test';
